﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GridSetting
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void ReadDataGridViewSetting(DataGridView dgv, string FileName)
        {

            XmlDocument xmldoc = new XmlDocument();
            XmlNodeList xmlnode;
            int i = 0;
            string str = null;
            FileStream fs = new FileStream("f:\\XML\\" + FileName + ".xml", FileMode.Open, FileAccess.Read);
            xmldoc.Load(fs);
            xmlnode = xmldoc.GetElementsByTagName("column");
            for (i = 0; i <= xmlnode.Count - 1; i++)
            {
                xmlnode[i].ChildNodes.Item(0).InnerText.Trim();
                string columnName = xmlnode[i].ChildNodes.Item(0).InnerText.Trim();
                int width = int.Parse(xmlnode[i].ChildNodes.Item(1).InnerText.Trim());
                string headertext = xmlnode[i].ChildNodes.Item(2).InnerText.Trim();
                int displayindex = int.Parse(xmlnode[i].ChildNodes.Item(3).InnerText.Trim());
                Boolean visible = Convert.ToBoolean(xmlnode[i].ChildNodes.Item(4).InnerText.Trim());
                dgv.Columns[columnName].Width = width;
                dgv.Columns[columnName].HeaderText = headertext;
                dgv.Columns[columnName].DisplayIndex = displayindex;
                dgv.Columns[columnName].Visible = visible;
                //MessageBox.Show(str);
            }
            fs.Close();
        }

        public void WriteGrideViewSetting(DataGridView dgv, string FileName)
        {

            XmlTextWriter textwriter = new XmlTextWriter("f:\\XML\\" + FileName + ".xml", null);
            textwriter.WriteStartDocument();
            textwriter.WriteStartElement(dgv.Name);

            int count = dgv.Columns.Count;
            for (int i = 0; i < count; i++)
            {

                textwriter.WriteStartElement("column");

                textwriter.WriteStartElement("Name");
                textwriter.WriteString(dgv.Columns[i].Name);
                textwriter.WriteEndElement();

                textwriter.WriteStartElement("width");
                textwriter.WriteString(dgv.Columns[i].Width.ToString());
                textwriter.WriteEndElement();

                textwriter.WriteStartElement("headertext");
                textwriter.WriteString(dgv.Columns[i].HeaderText);
                textwriter.WriteEndElement();

                textwriter.WriteStartElement("displayindex");
                textwriter.WriteString(dgv.Columns[i].DisplayIndex.ToString());
                textwriter.WriteEndElement();

                textwriter.WriteStartElement("visible");
                textwriter.WriteString(dgv.Columns[i].Visible.ToString());
                textwriter.WriteEndElement();

                textwriter.WriteEndElement();

            }
            textwriter.WriteEndElement();
            textwriter.WriteEndDocument();
            textwriter.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ReadDataGridViewSetting(dataGridView1, "firstgrid");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            WriteGrideViewSetting(dataGridView1, "firstgrid");
        }
    }
}
