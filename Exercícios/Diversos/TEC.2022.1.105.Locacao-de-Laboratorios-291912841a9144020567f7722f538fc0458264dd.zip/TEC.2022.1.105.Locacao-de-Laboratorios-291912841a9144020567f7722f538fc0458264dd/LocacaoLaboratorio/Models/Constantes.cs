﻿using System;

namespace Models
{
    public static class Constantes
    {
        public static int IdUsuarioLogado;
        public static string StringDeConexao;
        public static string DiretorioStringConexao = "C:\\Configuracao\\";
        public static string NomeArquivoConexao = "laboratoriosConnection.config";
    }
}
