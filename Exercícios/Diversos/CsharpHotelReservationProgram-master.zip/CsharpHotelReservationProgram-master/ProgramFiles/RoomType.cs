﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace project7
{   /// <summary>
    /// Enum class that has my roomtypes inside of it. with underlines(_).
    /// </summary>
    public enum RoomType
    {
        Single_Room,
        Lux_Room,
        Double_Room,
        Family_Room,
        Dormitory_Room
    }
}