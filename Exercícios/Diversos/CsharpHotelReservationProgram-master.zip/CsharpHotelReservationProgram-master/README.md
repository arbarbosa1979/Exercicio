# CsharpHotelReservationProgram
Hotel Reservation Program with C# Malmö University 2015

<img src="http://imgur.com/xGNJ0ED.png" width ="45%"/>&nbsp;&nbsp;&nbsp;<img src="http://imgur.com/wGI8yux.png" width ="45%"/>
