﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public static class Constantes
    {
        public static int IdUsuarioLogado;
        public static string StringDeConexao;
        public static string DiretorioStringConexao = "C:\\Configuracao\\";
        public static string NomeArquivoConexao = "sgreservasConnection.config";
    }
}
